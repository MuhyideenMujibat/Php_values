<?php
include "config.php";
?>

       
       <form action="#" method="post" enctype="multipart/form-data"> 
       <div class="row">
                     
                <div class="col-lg-6">
            <label for="cc-exp" class="control-label mb-1">Name</label>
            <br />
            <input type="text"  class="form-control" value="" name="name" required=""/>
       <br />
            <br />
</div>
         
<div class="col-lg-6">
         <label>Values</label>
                        <br />
                      <select name="choosen"  value="<?php ?>"   class="form-control" required="">
                     
                                          <?php
                                     
                                               $select = "SELECT * FROM inserted ";
                                          $result = mysqli_query($con,$select);
                                          while($results = mysqli_fetch_array($result)){ 
                                            $choosed = mysqli_real_escape_string($con,$results['inserted']);
                                            $choosed=$results['Name'];
                                      
                                           ?>
                                         
                                            <option value="<?php echo  $choosed; ?>" ><?php  echo  $choosed; ?></option>
                                          <?php
                                          }
                                          ?>
                                              </select>   
                   <br />
                   <br />
        </div>
                  
                    </div>
                  
                    <div id="show_button">
<button  name="submit" type="submit" id="submit"  >Submit</button>
                                  </div>

       </form>
       
    
       
      
         <?php
        
          if(isset($_POST['submit'])){
                 $name=$_POST['name'];
              $choosen=$_POST['choosen'];
            //   $grade="B";
            //   $score="4";

              $get=mysqli_query($con,"SELECT * FROM inserted WHERE Name='$choosen'");
            $row=mysqli_num_rows($get);
                        while($row = mysqli_fetch_array($get)){
                            $grade = $row['Letters'];
                            $score = $row['Figures'];
                    }

          $insert="INSERT INTO results (Name,Grade,Score) VALUES ( '$name','$grade','$score')";
          
          $sql=mysqli_query($con,$insert);
          if($sql){
              echo "SUCCESSFULL ";
          }else{
              echo "no insert ";
          }
         }
        
         ?>
         