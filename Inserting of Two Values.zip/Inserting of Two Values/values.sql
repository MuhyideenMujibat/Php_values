-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2024 at 01:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `values`
--

-- --------------------------------------------------------

--
-- Table structure for table `inserted`
--

CREATE TABLE `inserted` (
  `id` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Letters` varchar(100) NOT NULL,
  `Figures` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inserted`
--

INSERT INTO `inserted` (`id`, `Name`, `Letters`, `Figures`) VALUES
(1, 'A', 'A', '5'),
(2, 'B', 'B', '4'),
(3, 'C', 'C', '3'),
(4, 'D', 'D', '2'),
(5, 'E', 'E', '1');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Grade` varchar(100) NOT NULL,
  `Score` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `Name`, `Grade`, `Score`) VALUES
(6, 'Muftaudeen zainab apeke', 'A', '5'),
(7, 'Muhyideen Mujibat Olaide', 'B', '4'),
(8, 'Wasiu Samad', 'C', '3'),
(9, 'Wasiu Samad', 'C', '3'),
(10, 'ade mhi', 'D', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inserted`
--
ALTER TABLE `inserted`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
