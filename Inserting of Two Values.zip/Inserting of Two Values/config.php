<?php
$con=mysqli_connect("localhost","root","","values");
if($con){
    echo "";
}else{
    echo"error";
}


?>